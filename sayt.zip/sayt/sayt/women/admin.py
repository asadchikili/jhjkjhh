from django.contrib import admin
from .models import Women
# Register your models here.
admin.site.register(Women)