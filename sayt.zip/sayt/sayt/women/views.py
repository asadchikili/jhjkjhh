from rest_framework import generics
from django.shortcuts import render
from .models import Women
# Create your views here.
class WomenAPIView(genericks.ListAPIView):
    queryest = Women.objects.all()
    serializer_class = WomenSeriaLizer
