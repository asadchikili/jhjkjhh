from rest_framework import serializers
from .models import Women

class WomenSeriaLizer(serializers.ModelSeriaLizer):
    class Meta:
        model = Women
        fialds = ('title','cat_id')